#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <string>

#include "jefe.h" // Incluye Enemigo y Jefe de manera limpia

using namespace std;
 
// =====================================================================
// ESTRUCTURA PARA EL ARCHIVO BINARIO
// =====================================================================
struct RegistroPuntaje {
    char nombre[30];
    int puntaje;
    int oro;
};

// =====================================================================
// PERSONAJE
// =====================================================================
class Personaje {
public:
    string nombre;
    int vida;      
    int habilidad; 
    int oro;       
    int posX;      
    int posY;      
 
    Personaje(string _nombre, int x = 0, int y = 0) {
        nombre = _nombre;
        vida = 100;      
        habilidad = 20;  
        oro = 0;         
        posX = x;
        posY = y;
    }
 
    void setPosicion(int x, int y) {
        posX = x;
        posY = y;
    }
 
    void mover(string direccion) {
        if (direccion == "up") posY--;
        else if (direccion == "down") posY++;
        else if (direccion == "left") posX--;
        else if (direccion == "right") posX++;
    }
 
    void recibirDanio(int danio) {
        vida -= danio;
        if (vida <= 0) vida = 0; 
    }
 
    void curarConPocion(int cantidad) { vida += cantidad; }
    void ganarOro(int oroGanado) { oro += oroGanado; }
    void aumentarPV(int pvGanado) { vida += pvGanado; }
    void aumentarPH(int phGanado) { habilidad += phGanado; }
 
    bool estaVivo() const { return vida > 0; }
 
    int calcularPuntajeFinal(bool llegoALaSalida) const {
        int B = llegoALaSalida ? 100 : 0;
        return B + (oro * 2) + (vida * 2) + (habilidad * 5);
    }
 
    void imprimirStats() const {
        cout << "Stats:" << endl;
        cout << "PV: " << vida << endl;
        cout << "PH: " << habilidad << endl;
        cout << "Botin: " << oro << endl;
    }
};

// Implementación del método de Enemigo que requiere Personaje
void Enemigo::recibirDanio(int danio, Personaje &p) {
    if (vencido) return;
    vida -= danio;
    if (vida <= 0) {
        vida = 0; vencido = true;
        p.aumentarPH(phOtorgado);
        cout << "¡Has derrotado al enemigo! Ganas +" << phOtorgado << " de PH." << endl;
    } else {
        cout << "El enemigo recibe " << danio << " de daño. Vida restante: " << vida << endl;
    }
}
 
// =====================================================================
// COFRE
// =====================================================================
class Cofre {
public:
    int posX;
    int posY;
    bool abierto;
    char Contenido[101];
    char Desordenado[101];
    char valor;
 
    Cofre(int x = 0, int y = 0) {
        posX = x;
        posY = y;
        abierto = false;
 
        for(int i = 0; i < 100; i++) {
            if(i < 50) Contenido[i] = 'O'; 
            else if(i < 80) Contenido[i] = 'P'; 
            else Contenido[i] = 'T'; 
        }
        Contenido[100] = '\0';

        for(int i = 0; i < 100; i++) Desordenado[i] = Contenido[i];
        Desordenado[100] = '\0';

        char* ptr = Desordenado; 
        for(int i = 99; i > 0; i--){ 
            int j = rand() % (i + 1);
            char aux = *(ptr + i);
            *(ptr + i) = *(ptr + j);  
            *(ptr + j) = aux;
        }
        valor = *(ptr + (rand() % 100)); 
    }
 
    void explorarCofre(Personaje &p) { 
        if (abierto) {
            cout << "El cofre ya ha sido abierto" << endl;
            return;
        }
        abierto = true;

        switch (valor) {
            case 'O': p.ganarOro(10); cout << "Encontraste 10 de oro" << endl; break;
            case 'P': p.curarConPocion(50); cout << "Encontraste una pocion de vida, vida +50" << endl; break;
            case 'T': p.recibirDanio(30); cout << "El cofre era una trampa y caiste, perdiste 30 puntos de vida" << endl; break;
        }
    }
 
    char obtenerSimbolo() const { return abierto ? 'O' : '?'; }
    int getPosX() const { return posX; }
    int getPosY() const { return posY; }
};
 
// =====================================================================
// GOBLIN Y ARQUERO
// =====================================================================
class Goblin : public Enemigo {
public:
    Goblin(int x = 0, int y = 0) : Enemigo(x, y, 30, 2, 'G') {}
    void atacarGoblin(Personaje &p) {
        if (!vencido) {
            descubrir();
            p.recibirDanio(30);
            cout << "El Goblin te ataco cuerpo a cuerpo! Pierdes 30 PV." << endl;
        }
    }
};
 
class Arquero : public Enemigo {
public:
    Arquero(int x = 0, int y = 0) : Enemigo(x, y, 20, 3, 'A') {}
    void atacarArquero(Personaje &p) {
        if (!vencido) {
            descubrir();
            p.recibirDanio(20);
            cout << "El Arquero te disparo desde una casilla adyacente! Pierdes 20 PV." << endl;
        }
    }
};

// =====================================================================
// FUNCIONES DE TABLERO Y POSICIONAMIENTO
// =====================================================================
void mostrarTablero(int filas, int columnas, Personaje &jugador,
                     Goblin *goblins, int numGoblins,
                     Arquero *arqueros, int numArqueros,
                     Cofre *cofres, int numCofres,
                     int salidaX, int salidaY, Jefe &jefe) {

    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            bool impreso = false;
 
            if (i == jugador.posY && j == jugador.posX) { cout << "[ @ ]"; impreso = true; }
            if (!impreso && i == salidaY && j == salidaX) { cout << "[ # ]"; impreso = true; }
            if (!impreso) {
                for (int k = 0; k < numCofres; k++) {
                    if (i == cofres[k].posY && j == cofres[k].posX) {
                        cout << "[ " << cofres[k].obtenerSimbolo() << " ]";
                        impreso = true; break;
                    }
                }
            }
            if (!impreso) {
                for (int k = 0; k < numGoblins; k++) {
                    if (i == goblins[k].getPosY() && j == goblins[k].getPosX()) {
                        cout << "[ " << goblins[k].getSimbolo() << " ]";
                        impreso = true; break;
                    }
                }
            }
            if (!impreso) {
                for (int k = 0; k < numArqueros; k++) {
                    if (i == arqueros[k].getPosY() && j == arqueros[k].getPosX()) {
                        cout << "[ " << arqueros[k].getSimbolo() << " ]";
                        impreso = true; break;
                    }
                }
            }
            if (!impreso && jefe.getPosY() == i && jefe.getPosX() == j) {
                cout << (jefe.estaVencido() ? "[ X ]" : "[ J ]");
                impreso = true;
            }
            if (!impreso) cout << "[ - ]";
        }
        cout << endl;
    }
}

int casillaOcupada(Personaje &jugador, Goblin *goblins, int numGoblins,
                   Arquero *arqueros, int numArqueros, Cofre *cofres, Jefe &jefe, int numCofres,
                   int salidaX, int salidaY, int filas, int columnas, int x, int y) {
    if (jugador.posX == x && jugador.posY == y) return 1;
    if (salidaX == x && salidaY == y) return 1;
    for (int i = 0; i < numGoblins; i++) if (goblins[i].getPosX() == x && goblins[i].getPosY() == y) return 1;
    for (int i = 0; i < numArqueros; i++) if (arqueros[i].getPosX() == x && arqueros[i].getPosY() == y) return 1;
    for (int i = 0; i < numCofres; i++) if (cofres[i].getPosX() == x && cofres[i].getPosY() == y) return 1;
    if (abs(x - jugador.posX) <= 1 && abs(y - jugador.posY) <= 1) return 1;
    if (jefe.getPosX() == x && jefe.getPosY() == y) return 1;
    return 0;
}

void buscarLibre(int &x, int &y, int filas, int columnas, Personaje &jugador,
                 Goblin *goblins, int numGoblins, Arquero *arqueros, int numArqueros,
                 Cofre *cofres, int numCofres, int salidaX, int salidaY, Jefe &jefe) {
    int intentos = 0;
    while (casillaOcupada(jugador, goblins, numGoblins, arqueros, numArqueros, cofres, jefe, numCofres, salidaX, salidaY, filas, columnas, x, y) == 1
           && intentos < filas * columnas * 10) {
        x = rand() % columnas; y = rand() % filas; intentos++;
    }
}

void crearPosicionJefe(Jefe &jefe, int filas, int columnas, Personaje &jugador, Goblin *goblins, int numGoblins, 
    Arquero *arqueros, int numArqueros, Cofre *cofres, int numCofres) {
    int x, y;
    bool ocupada;
    do {
        x = rand() % columnas; y = rand() % filas; ocupada = false;
        if (jugador.posX == x && jugador.posY == y) ocupada = true;
        for (int i = 0; i < numGoblins; i++) if (goblins[i].getPosX() == x && goblins[i].getPosY() == y) ocupada = true;
        for (int i = 0; i < numArqueros; i++) if (arqueros[i].getPosX() == x && arqueros[i].getPosY() == y) ocupada = true;
        for (int i = 0; i < numCofres; i++) if (cofres[i].getPosX() == x && cofres[i].getPosY() == y) ocupada = true;
    } while (ocupada);
    jefe = Jefe(x, y);
    cout << "Posicion del jefe: (" << x << ", " << y << ")" << endl;
}

void movimientojefe(
    Jefe &jefe,
    Personaje &jugador,
    int salidaX,
    int salidaY)
{
    if (jefe.estaVencido()) {
        return;
    }

    // Aumenta el contador de turnos
    jefe.aumentarTurno();

    cout << "Turno del jefe: "
         << jefe.getTurnos() << endl;

    // El jefe solamente se mueve cada 2 turnos
    if (jefe.debeMoverse()) {

        cout << "El jefe esta buscando interceptarte..." << endl;

        jefe.interceptar(
            jugador.posX,
            jugador.posY,
            salidaX,
            salidaY
        );

        cout << "El jefe se ha movido." << endl;

        cout << "Nueva posicion del jefe: ("
             << jefe.getPosX() << ", "
             << jefe.getPosY() << ")"
             << endl;
    }
}

void crearposiciones(Personaje &jugador, Goblin *goblins, int numGoblins,
                     Arquero *arqueros, int numArqueros, Cofre *cofres, Jefe &jefe, int numCofres,
                     int &salidaX, int &salidaY, int filas, int columnas) {
    
    jugador.setPosicion(rand() % columnas, rand() % filas);

    do {
        int borde = rand() % 4; 
        if (borde == 0) { salidaY = 0; salidaX = rand() % columnas; }
        else if (borde == 1) { salidaY = filas - 1; salidaX = rand() % columnas; }
        else if (borde == 2) { salidaX = 0; salidaY = rand() % filas; }
        else { salidaX = columnas - 1; salidaY = rand() % filas; }
    } while (salidaX == jugador.posX && salidaY == jugador.posY);

    cout << "Posicion de la salida (en el borde): (" << salidaX << ", " << salidaY << ")" << endl;

    for (int i = 0; i < numGoblins; i++) {
        int x = rand() % columnas, y = rand() % filas;
        buscarLibre(x, y, filas, columnas, jugador, goblins, i, arqueros, 0, cofres, 0, salidaX, salidaY, jefe);
        goblins[i] = Goblin(x, y);
    }
    for (int i = 0; i < numArqueros; i++) {
        int x = rand() % columnas, y = rand() % filas;
        buscarLibre(x, y, filas, columnas, jugador, goblins, numGoblins, arqueros, i, cofres, 0, salidaX, salidaY, jefe);
        arqueros[i] = Arquero(x, y);
    }
    for (int i = 0; i < numCofres; i++) {
        int x = rand() % columnas, y = rand() % filas;
        buscarLibre(x, y, filas, columnas, jugador, goblins, numGoblins, arqueros, numArqueros, cofres, i, salidaX, salidaY, jefe);
        cofres[i] = Cofre(x, y);
    }
    crearPosicionJefe(jefe, filas, columnas, jugador, goblins, numGoblins, arqueros, numArqueros, cofres, numCofres);
}

// =====================================================================
// ARCHIVOS BINARIOS
// =====================================================================
void guardarPuntajeBinario(const Personaje &jugador, int puntajeFinal) {
    ofstream archivoBin("puntajes.dat", ios::out | ios::binary | ios::app);
    if (archivoBin.is_open()) {
        RegistroPuntaje reg;
        int i = 0;
        while (i < 29 && i < jugador.nombre.length()) { reg.nombre[i] = jugador.nombre[i]; i++; }
        reg.nombre[i] = '\0';
        reg.puntaje = puntajeFinal;
        reg.oro = jugador.oro;
        archivoBin.write(reinterpret_cast<char*>(&reg), sizeof(RegistroPuntaje));
        archivoBin.close();
        cout << "[Binario] Partida guardada en 'puntajes.dat'." << endl;
    }
}

void leerPuntajesBinarios() {
    ifstream archivoBin("puntajes.dat", ios::in | ios::binary);
    if (!archivoBin.is_open()) {
        cout << "No hay registros binarios anteriores todavía." << endl;
        return;
    }
    RegistroPuntaje reg;
    cout << "\n=== HISTORIAL DE PUNTAJES (BINARIO) ===" << endl;
    while (archivoBin.read(reinterpret_cast<char*>(&reg), sizeof(RegistroPuntaje))) {
        cout << "Jugador: " << reg.nombre << " | Puntaje: " << reg.puntaje << " | Oro: " << reg.oro << endl;
    }
    cout << "=======================================" << endl;
    archivoBin.close();
}

// =====================================================================
// MAIN
// =====================================================================
int main(){
    srand(time(NULL));
 
    int filas, columnas;
    int salidaX = 0, salidaY = 0;
    char opcion;
    Personaje jugador("Heroe");  
    Jefe jefe;

    cout << "Digite 'iniciar' para comenzar el juego: ";
    string input;
    cin >> input;

    int numGoblins, numArqueros, numCofres;

    cout << "El juego ha comenzado" << endl;
    cout << "Digita las filas del tablero: "; cin >> filas;
    cout << "Digita las columnas del tablero: "; cin >> columnas;
    cout << "Digita la cantidad de goblins: "; cin >> numGoblins;
    Goblin *goblins = new Goblin[numGoblins];
    cout << "Digita la cantidad de arqueros: "; cin >> numArqueros;
    Arquero *arqueros = new Arquero[numArqueros];
    cout << "Digita la cantidad de cofres: "; cin >> numCofres;
    Cofre *cofres = new Cofre[numCofres];

    crearposiciones(jugador, goblins, numGoblins, arqueros, numArqueros, cofres, jefe, numCofres, salidaX, salidaY, filas, columnas);

    while(input == "Iniciar" || input == "iniciar" || input == "INICIAR"){
        
        if(jugador.posX == salidaX && jugador.posY == salidaY) {
            cout << "¡Felicidades! Has llegado a la salida." << endl;
            int puntajeFinal = jugador.calcularPuntajeFinal(true);
            cout << "Tu puntaje final es: " << puntajeFinal << endl;
            guardarPuntajeBinario(jugador, puntajeFinal);
            break; 
        }

        cout << "\n----------------------------------------" << endl;
        cout << " Digite 'E' para explorar casilla" << endl;
        cout << " Digite 'M' para moverse" << endl;
        cout << " Digite 'P' para ver el mapa" << endl;
        cout << " Digite 'T' para ver estadísticas" << endl;
        cout << " Digite 'H' para ver el historial binario" << endl;
        cout << " Digite 'S' para salir" << endl;
        cout << "Elige una opcion: ";
        cin >> opcion;
        
        if(opcion == 'E' || opcion == 'e'){
            for (int i = 0; i < numCofres; i++) {
                if (jugador.posX == cofres[i].getPosX() && jugador.posY == cofres[i].getPosY()) {
                    cofres[i].explorarCofre(jugador); break;
                }
            }
            for (int i = 0; i < numGoblins; i++) {
                if ((jugador.posX == goblins[i].getPosX() && jugador.posY == goblins[i].getPosY()) && !goblins[i].estaVencido()) {
                    goblins[i].atacarGoblin(jugador);
                    cout << "Digita 'A' para atacar o 'M' para moverte: ";
                    char accion; cin >> accion;
                    if(accion == 'A' || accion == 'a') goblins[i].recibirDanio(20, jugador);
                    else if(accion == 'M' || accion == 'm') {
                        cout << "Direccion (d, a, w, s): "; char dir; cin >> dir;
                        if(dir == 'd') jugador.mover("right");
                        else if(dir == 'a') jugador.mover("left");
                        else if(dir == 'w') jugador.mover("up");
                        else if(dir == 's') jugador.mover("down");
                        movimientojefe(jefe, jugador, salidaX, salidaY);
                    }
                }
            }
            for (int i = 0; i < numArqueros; i++) {
                bool rX = abs(jugador.posX - arqueros[i].getPosX()) <= 1;
                bool rY = abs(jugador.posY - arqueros[i].getPosY()) <= 1;
                if ((rX && rY) && !arqueros[i].estaVencido()) {
                    arqueros[i].atacarArquero(jugador);
                    cout << "Digita 'A' para atacar o 'M' para moverte: ";
                    char accion; cin >> accion;
                    if(accion == 'A' || accion == 'a') arqueros[i].recibirDanio(20, jugador);
                    else if(accion == 'M' || accion == 'm') {
                        cout << "Direccion (d, a, w, s): "; char dir; cin >> dir;
                        if(dir == 'd') jugador.mover("right");
                        else if(dir == 'a') jugador.mover("left");
                        else if(dir == 'w') jugador.mover("up");
                        else if(dir == 's') jugador.mover("down");
                        movimientojefe(jefe, jugador, salidaX, salidaY);
                    }
                }
            }
            if((jugador.posX == jefe.getPosX() && jugador.posY == jefe.getPosY()) && !jefe.estaVencido()) {
                cout << "¡Has encontrado al Jefe!" << endl;
                cout << "Digita 'A' para atacar o 'M' para moverte: ";
                char accion; cin >> accion;
                if(accion == 'A' || accion == 'a') jefe.recibirDanio(20, jugador);
                else if(accion == 'M' || accion == 'm') {
                    cout << "Direccion (d, a, w, s): "; char dir; cin >> dir;
                    if(dir == 'd') jugador.mover("right");
                    else if(dir == 'a') jugador.mover("left");
                    else if(dir == 'w') jugador.mover("up");
                    else if(dir == 's') jugador.mover("down");
                    movimientojefe(jefe, jugador, salidaX, salidaY);
                }
            }
        }
        else if(opcion == 'M' || opcion == 'm'){
            cout << "Direccion (d, a, w, s): "; char dir; cin >> dir;
            if(dir == 'd') jugador.mover("right");
            else if(dir == 'a') jugador.mover("left");
            else if(dir == 'w') jugador.mover("up");
            else if(dir == 's') jugador.mover("down");
            movimientojefe(jefe, jugador, salidaX, salidaY);
        } 
        else if(opcion == 'P' || opcion == 'p'){
            mostrarTablero(filas, columnas, jugador, goblins, numGoblins, arqueros, numArqueros, cofres, numCofres, salidaX, salidaY, jefe);
        }
        else if(opcion == 'T' || opcion == 't'){
            jugador.imprimirStats();
        }
        else if(opcion == 'H' || opcion == 'h'){
            leerPuntajesBinarios();
        }
        else if(opcion == 'S' || opcion == 's'){
            guardarPuntajeBinario(jugador, jugador.calcularPuntajeFinal(false));
            break;
        }
    }

    delete[] goblins;
    delete[] arqueros;
    delete[] cofres;
    
    return 0;
}