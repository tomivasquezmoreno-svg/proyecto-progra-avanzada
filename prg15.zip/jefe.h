#ifndef JEFE_H
#define JEFE_H

#include <iostream>
#include <string>

using namespace std;

// Declaración adelantada de la clase Personaje para evitar conflictos
class Personaje;

// =====================================================================
// CLASE ENEMIGO (Base)
// =====================================================================
class Enemigo {
protected:
    int posX;
    int posY;
    int vida;
    int phOtorgado; 
    bool vencido;
    bool descubierto; 
    char simboloReal; 
 
public:
    Enemigo(int x = 0, int y = 0, int v = 0, int pH = 0, char s = ' ') {
        posX = x; 
        posY = y; 
        vida = v; 
        phOtorgado = pH;
        vencido = false; 
        descubierto = false; 
        simboloReal = s;
    }
 
    // Declaración del método que interactúa con el Personaje
    void recibirDanio(int danio, Personaje &p);
 
    void descubrir() { descubierto = true; }
    bool estaVencido() const { return vencido; }
    bool estaDescubierto() const { return descubierto; }

    char getSimbolo() const { 
        if (vencido) return 'X';       
        if (!descubierto) return 'E';  
        return simboloReal;            
    } 

    int getVida() const { return vida; }
    int getPhOtorgado() const { return phOtorgado; }
    int getPosX() const { return posX; }
    int getPosY() const { return posY; }
};

// =====================================================================
// =====================================================================
// BOSS (JEFE)
// =====================================================================
class Jefe : public Enemigo {
public:
    int turnos;

    Jefe(int x = 0, int y = 0)
        : Enemigo(x, y, 60, 5, 'J') {
        turnos = 0;
    }

    void aumentarTurno() {
        turnos++;
    }

    int getTurnos() const {
        return turnos;
    }

    bool debeMoverse() const {
        return turnos % 2 == 0;
    }

    // Mueve al jefe UNA casilla hacia un objetivo
    void moverUnaCasillaHacia(int objetivoX, int objetivoY) {

        int diferenciaX = abs(objetivoX - posX);
        int diferenciaY = abs(objetivoY - posY);

        // Si hay mayor distancia horizontal,
        // se mueve horizontalmente.
        if (diferenciaX > diferenciaY) {

            if (objetivoX > posX) {
                posX++;
            }
            else if (objetivoX < posX) {
                posX--;
            }
        }

        // Si hay mayor distancia vertical,
        // se mueve verticalmente.
        else if (diferenciaY > diferenciaX) {

            if (objetivoY > posY) {
                posY++;
            }
            else if (objetivoY < posY) {
                posY--;
            }
        }

        // Si las distancias son iguales,
        // escogemos primero el movimiento horizontal.
        else {

            if (objetivoX > posX) {
                posX++;
            }
            else if (objetivoX < posX) {
                posX--;
            }
            else if (objetivoY > posY) {
                posY++;
            }
            else if (objetivoY < posY) {
                posY--;
            }
        }
    }

    // Busca el punto del camino jugador -> salida
    // que está más cerca del jefe.
    void interceptar(
        int jugadorX,
        int jugadorY,
        int salidaX,
        int salidaY)
    {
        int x = jugadorX;
        int y = jugadorY;

        int mejorX = jugadorX;
        int mejorY = jugadorY;

        int mejorDistancia =
            abs(posX - x) +
            abs(posY - y);

        // Recorremos el camino más corto
        // entre el jugador y la salida.
        while (x != salidaX || y != salidaY) {

            int diferenciaX = abs(salidaX - x);
            int diferenciaY = abs(salidaY - y);

            // Avanzamos por X si esa distancia
            // es mayor o igual.
            if (diferenciaX >= diferenciaY) {

                if (salidaX > x) {
                    x++;
                }
                else if (salidaX < x) {
                    x--;
                }
            }

            // Si no, avanzamos por Y.
            else {

                if (salidaY > y) {
                    y++;
                }
                else if (salidaY < y) {
                    y--;
                }
            }

            // Distancia del jefe hasta esta casilla
            int distanciaJefe =
                abs(posX - x) +
                abs(posY - y);

            // Guardamos la casilla del camino
            // más cercana al jefe.
            if (distanciaJefe < mejorDistancia) {

                mejorDistancia = distanciaJefe;

                mejorX = x;
                mejorY = y;
            }
        }

        cout << "Punto de intercepcion: ("
             << mejorX << ", "
             << mejorY << ")" << endl;

        // El jefe solamente avanza UNA casilla
        // hacia el punto de intercepcion.
        moverUnaCasillaHacia(mejorX, mejorY);
    }
};

#endif