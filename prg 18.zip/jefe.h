#ifndef JEFE_H
#define JEFE_H

#include <iostream>
#include <string>
#include <cstdlib>
#include <cmath>

using namespace std;

class Personaje;

// =====================================================================
// CLASE ENEMIGO (Base)
// =====================================================================
class Enemigo {
protected:
    int posX;
    int posY;
    int vida;
    int phOtorgado; 
    bool vencido;
    bool descubierto; 
    char simboloReal; 
 
public:
    Enemigo(int x = 0, int y = 0, int v = 0, int pH = 0, char s = ' ') {
        posX = x; 
        posY = y; 
        vida = v; 
        phOtorgado = pH;
        vencido = false; 
        descubierto = false; 
        simboloReal = s;
    }
 
    void recibirDanio(int danio, Personaje &p);
 
    void descubrir() { descubierto = true; }
    bool estaVencido() const { return vencido; }
    bool estaDescubierto() const { return descubierto; }

    char getSimbolo() const { 
        if (vencido) return 'X';       
        if (!descubierto) return 'E';  
        return simboloReal;            
    } 

    int getVida() const { return vida; }
    int getPhOtorgado() const { return phOtorgado; }
    int getPosX() const { return posX; }
    int getPosY() const { return posY; }
};

// =====================================================================
// BOSS (JEFE)
// =====================================================================
class Jefe : public Enemigo {
public:
    int turnos;

    Jefe(int x = 0, int y = 0, int v = 60, int t = 0, bool venc = false)
        : Enemigo(x, y, v, 5, 'J') {
        turnos = t;
        vencido = venc;
    }

    void aumentarTurno() {
        turnos++;
    }

    int getTurnos() const {
        return turnos;
    }

    bool debeMoverse() const {
        return turnos % 2 == 0;
    }

    void moverUnaCasillaHacia(int objetivoX, int objetivoY) {
        int diferenciaX = abs(objetivoX - posX);
        int diferenciaY = abs(objetivoY - posY);

        if (diferenciaX > diferenciaY) {
            if (objetivoX > posX) posX++;
            else if (objetivoX < posX) posX--;
        }
        else if (diferenciaY > diferenciaX) {
            if (objetivoY > posY) posY++;
            else if (objetivoY < posY) posY--;
        }
        else {
            if (objetivoX > posX) posX++;
            else if (objetivoX < posX) posX--;
            else if (objetivoY > posY) posY++;
            else if (objetivoY < posY) posY--;
        }
    }

    void interceptar(int jugadorX, int jugadorY, int salidaX, int salidaY) {
        int x = jugadorX;
        int y = jugadorY;
        int mejorX = jugadorX;
        int mejorY = jugadorY;
        int mejorDistancia = abs(posX - x) + abs(posY - y);

        while (x != salidaX || y != salidaY) {
            int diferenciaX = abs(salidaX - x);
            int diferenciaY = abs(salidaY - y);

            if (diferenciaX >= diferenciaY) {
                if (salidaX > x) x++;
                else if (salidaX < x) x--;
            } else {
                if (salidaY > y) y++;
                else if (salidaY < y) y--;
            }

            int distanciaJefe = abs(posX - x) + abs(posY - y);
            if (distanciaJefe < mejorDistancia) {
                mejorDistancia = distanciaJefe;
                mejorX = x;
                mejorY = y;
            }
        }

        moverUnaCasillaHacia(mejorX, mejorY);
    }
};

#endif