#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <string>

#include "jefe.h"

using namespace std;

struct RegistroPuntaje {
    char nombre[30];
    int puntaje;
    int oro;
};

struct GoblinData { int x, y, vida; bool vencido, descubierto; };
struct ArqueroData { int x, y, vida; bool vencido, descubierto; };
struct CofreData { int x, y; bool abierto; char valor; };

struct EstadoJuego {
    bool activo;
    int filas;
    int columnas;
    int jugadorX;
    int jugadorY;
    int vida;
    int habilidad;
    int oro;
    int salidaX;
    int salidaY;
    
    int numGoblins;
    GoblinData goblins[20];

    int numArqueros;
    ArqueroData arqueros[20];

    int numCofres;
    CofreData cofres[20];

    int jefeX;
    int jefeY;
    int jefeVida;
    bool jefeVencido;
    int jefeTurnos;
};

class Personaje {
public:
    string nombre;
    int vida;      
    int habilidad; 
    int oro;       
    int posX;      
    int posY;      
 
    Personaje(string _nombre, int x = 0, int y = 0) {
        nombre = _nombre;
        vida = 100;      
        habilidad = 20;  
        oro = 0;         
        posX = x;
        posY = y;
    }
 
    void setPosicion(int x, int y) {
        posX = x;
        posY = y;
    }
 
    void mover(string direccion) {
        if (direccion == "up") posY--;
        else if (direccion == "down") posY++;
        else if (direccion == "left") posX--;
        else if (direccion == "right") posX++;
    }
 
    void recibirDanio(int danio) {
        vida -= danio;
        if (vida <= 0) vida = 0; 
    }
 
    void curarConPocion(int cantidad) { vida += cantidad; }
    void ganarOro(int oroGanado) { oro += oroGanado; }
    void aumentarPV(int pvGanado) { vida += pvGanado; }
    void aumentarPH(int phGanado) { habilidad += phGanado; }
 
    bool estaVivo() const { return vida > 0; }
 
    int calcularPuntajeFinal(bool llegoALaSalida) const {
        int B = llegoALaSalida ? 100 : 0;
        return B + (oro * 2) + (vida * 2) + (habilidad * 5);
    }
 
    void imprimirStats() const {
        cout << "Stats:" << endl;
        cout << "PV: " << vida << endl;
        cout << "PH: " << habilidad << endl;
        cout << "Botin: " << oro << endl;
    }
};

void Enemigo::recibirDanio(int danio, Personaje &p) {
    if (vencido) return;
    vida -= danio;
    if (vida <= 0) {
        vida = 0; vencido = true;
        p.aumentarPH(phOtorgado);
        cout << "¡Has derrotado al enemigo! Ganas +" << phOtorgado << " de PH." << endl;
    } else {
        cout << "El enemigo recibe " << danio << " de daño. Vida restante: " << vida << endl;
    }
}
 
class Cofre {
public:
    int posX;
    int posY;
    bool abierto;
    char valor;
 
    Cofre(int x = 0, int y = 0, bool ab = false, char v = 'O') {
        posX = x;
        posY = y;
        abierto = ab;
        valor = v;
    }
 
    void explorarCofre(Personaje &p) { 
        if (abierto) {
            cout << "El cofre ya ha sido abierto" << endl;
            return;
        }
        abierto = true;

        switch (valor) {
            case 'O': p.ganarOro(10); cout << "Encontraste 10 de oro" << endl; break;
            case 'P': p.curarConPocion(50); cout << "Encontraste una pocion de vida, vida +50" << endl; break;
            case 'T': p.recibirDanio(30); cout << "El cofre era una trampa y caiste, perdiste 30 puntos de vida" << endl; break;
        }
    }
 
    char obtenerSimbolo() const { return abierto ? 'O' : '?'; }
    int getPosX() const { return posX; }
    int getPosY() const { return posY; }
};
 
class Goblin : public Enemigo {
public:
    Goblin(int x = 0, int y = 0, int v = 30, bool venc = false, bool desc = false) : Enemigo(x, y, v, 2, 'G') {
        vencido = venc;
        descubierto = desc;
    }
};
 
class Arquero : public Enemigo {
public:
    Arquero(int x = 0, int y = 0, int v = 20, bool venc = false, bool desc = false) : Enemigo(x, y, v, 3, 'A') {
        vencido = venc;
        descubierto = desc;
    }
};

void guardarEstado(const EstadoJuego &est) {
    ofstream archivo("partida_juego.dat", ios::out | ios::binary);
    if (archivo.is_open()) {
        archivo.write(reinterpret_cast<const char*>(&est), sizeof(EstadoJuego));
        archivo.close();
    }
}

bool cargarEstado(EstadoJuego &est) {
    ifstream archivo("partida_juego.dat", ios::in | ios::binary);
    if (archivo.is_open()) {
        archivo.read(reinterpret_cast<char*>(&est), sizeof(EstadoJuego));
        archivo.close();
        return est.activo;
    }
    return false;
}

void mostrarTablero(int filas, int columnas, Personaje &jugador,
                     Goblin *goblins, int numGoblins,
                     Arquero *arqueros, int numArqueros,
                     Cofre *cofres, int numCofres,
                     int salidaX, int salidaY, Jefe &jefe) {

    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            bool impreso = false;
 
            if (i == jugador.posY && j == jugador.posX) { cout << "[ @ ]"; impreso = true; }
            else if (!impreso && i == salidaY && j == salidaX) { cout << "[ # ]"; impreso = true; }
            else {
                for (int k = 0; k < numCofres; k++) {
                    if (i == cofres[k].getPosY() && j == cofres[k].getPosX()) {
                        cout << "[ " << cofres[k].obtenerSimbolo() << " ]";
                        impreso = true; break;
                    }
                }
            }
            if (!impreso) {
                for (int k = 0; k < numGoblins; k++) {
                    if (i == goblins[k].getPosY() && j == goblins[k].getPosX()) {
                        cout << "[ " << goblins[k].getSimbolo() << " ]";
                        impreso = true; break;
                    }
                }
            }
            if (!impreso) {
                for (int k = 0; k < numArqueros; k++) {
                    if (i == arqueros[k].getPosY() && j == arqueros[k].getPosX()) {
                        cout << "[ " << arqueros[k].getSimbolo() << " ]";
                        impreso = true; break;
                    }
                }
            }
            if (!impreso && jefe.getPosY() == i && jefe.getPosX() == j) {
                cout << (jefe.estaVencido() ? "[ X ]" : "[ J ]");
                impreso = true;
            }
            if (!impreso) cout << "[ - ]";
        }
        cout << endl;
    }
}

int casillaOcupada(Personaje &jugador, Goblin *goblins, int numGoblins,
                   Arquero *arqueros, int numArqueros, Cofre *cofres, Jefe &jefe, int numCofres,
                   int salidaX, int salidaY, int filas, int columnas, int x, int y) {
    if (jugador.posX == x && jugador.posY == y) return 1;
    if (salidaX == x && salidaY == y) return 1;
    for (int i = 0; i < numGoblins; i++) if (goblins[i].getPosX() == x && goblins[i].getPosY() == y) return 1;
    for (int i = 0; i < numArqueros; i++) if (arqueros[i].getPosX() == x && arqueros[i].getPosY() == y) return 1;
    for (int i = 0; i < numCofres; i++) if (cofres[i].getPosX() == x && cofres[i].getPosY() == y) return 1;
    if (abs(x - jugador.posX) <= 1 && abs(y - jugador.posY) <= 1) return 1;
    if (jefe.getPosX() == x && jefe.getPosY() == y) return 1;
    return 0;
}

void buscarLibre(int &x, int &y, int filas, int columnas, Personaje &jugador,
                 Goblin *goblins, int numGoblins, Arquero *arqueros, int numArqueros,
                 Cofre *cofres, int numCofres, int salidaX, int salidaY, Jefe &jefe) {
    int intentos = 0;
    while (casillaOcupada(jugador, goblins, numGoblins, arqueros, numArqueros, cofres, jefe, numCofres, salidaX, salidaY, filas, columnas, x, y) == 1
           && intentos < filas * columnas * 10) {
        x = rand() % columnas; y = rand() % filas; intentos++;
    }
}

void crearPosicionJefe(Jefe &jefe, int filas, int columnas, Personaje &jugador, Goblin *goblins, int numGoblins, 
    Arquero *arqueros, int numArqueros, Cofre *cofres, int numCofres, int salidaX, int salidaY) {
    int x, y;
    bool ocupada;
    do {
        x = rand() % columnas; y = rand() % filas; ocupada = false;
        if (jugador.posX == x && jugador.posY == y) ocupada = true;
        if (salidaX == x && salidaY == y) ocupada = true; 
        for (int i = 0; i < numGoblins; i++) if (goblins[i].getPosX() == x && goblins[i].getPosY() == y) ocupada = true;
        for (int i = 0; i < numArqueros; i++) if (arqueros[i].getPosX() == x && arqueros[i].getPosY() == y) ocupada = true;
        for (int i = 0; i < numCofres; i++) if (cofres[i].getPosX() == x && cofres[i].getPosY() == y) ocupada = true;
    } while (ocupada);
    jefe = Jefe(x, y, 60, 0, false);
}

void movimientojefe(Jefe &jefe, Personaje &jugador, int salidaX, int salidaY) {
    if (jefe.estaVencido()) return;
    jefe.aumentarTurno();
    if (jefe.debeMoverse()) {
        jefe.interceptar(jugador.posX, jugador.posY, salidaX, salidaY);
    }
}

void guardarPuntajeBinario(const Personaje &jugador, int puntajeFinal) {
    ofstream archivoBin("puntajes.dat", ios::out | ios::binary | ios::app);
    if (archivoBin.is_open()) {
        RegistroPuntaje reg;
        int i = 0;
        while (i < 29 && i < jugador.nombre.length()) { reg.nombre[i] = jugador.nombre[i]; i++; }
        reg.nombre[i] = '\0';
        reg.puntaje = puntajeFinal;
        reg.oro = jugador.oro;
        archivoBin.write(reinterpret_cast<char*>(&reg), sizeof(RegistroPuntaje));
        archivoBin.close();
    }
}

void leerPuntajesBinarios() {
    ifstream archivoBin("puntajes.dat", ios::in | ios::binary);
    if (!archivoBin.is_open()) {
        cout << "No hay registros binarios anteriores todavía." << endl;
        return;
    }
    RegistroPuntaje reg;
    cout << "\n=== HISTORIAL DE PUNTAJES (BINARIO) ===" << endl;
    while (archivoBin.read(reinterpret_cast<char*>(&reg), sizeof(RegistroPuntaje))) {
        cout << "Jugador: " << reg.nombre << " | Puntaje: " << reg.puntaje << " | Oro: " << reg.oro << endl;
    }
    cout << "=======================================" << endl;
    archivoBin.close();
}

int main(int argc, char* argv[]) {
    srand(time(NULL));

    if (argc < 2) {
        cout << "Uso: ./juego.exe [start [filas] [columnas] [goblins] [arqueros] | board | stats | move <dir> | seek | attack | history]" << endl;
        return 0;
    }

    string comando = argv[1];

    if (comando == "start") {
        int filas = 10, columnas = 10;
        int numGoblins = 1, numArqueros = 2, numCofres = 3;

        if (argc >= 4) {
            filas = stoi(argv[2]);
            columnas = stoi(argv[3]);
        }
        if (argc >= 5) numGoblins = stoi(argv[4]);
        if (argc >= 6) numArqueros = stoi(argv[5]);

        if (numGoblins > 20) numGoblins = 20;
        if (numArqueros > 20) numArqueros = 20;

        Personaje jugador("Heroe");
        Jefe jefe;
        Goblin *goblins = new Goblin[numGoblins];
        Arquero *arqueros = new Arquero[numArqueros];
        Cofre *cofres = new Cofre[numCofres];

        jugador.setPosicion(rand() % columnas, rand() % filas);
        int salidaX = 0, salidaY = 0;
        do {
            int borde = rand() % 4; 
            if (borde == 0) { salidaY = 0; salidaX = rand() % columnas; }
            else if (borde == 1) { salidaY = filas - 1; salidaX = rand() % columnas; }
            else if (borde == 2) { salidaX = 0; salidaY = rand() % filas; }
            else { salidaX = columnas - 1; salidaY = rand() % filas; }
        } while (salidaX == jugador.posX && salidaY == jugador.posY);

        for (int i = 0; i < numGoblins; i++) {
            int x = rand() % columnas, y = rand() % filas;
            buscarLibre(x, y, filas, columnas, jugador, goblins, i, arqueros, 0, cofres, 0, salidaX, salidaY, jefe);
            goblins[i] = Goblin(x, y);
        }
        for (int i = 0; i < numArqueros; i++) {
            int x = rand() % columnas, y = rand() % filas;
            buscarLibre(x, y, filas, columnas, jugador, goblins, numGoblins, arqueros, i, cofres, 0, salidaX, salidaY, jefe);
            arqueros[i] = Arquero(x, y);
        }
        for (int i = 0; i < numCofres; i++) {
            int x = rand() % columnas, y = rand() % filas;
            buscarLibre(x, y, filas, columnas, jugador, goblins, numGoblins, arqueros, numArqueros, cofres, i, salidaX, salidaY, jefe);
            char tipos[] = {'O', 'P', 'T'};
            cofres[i] = Cofre(x, y, false, tipos[rand() % 3]);
        }
        crearPosicionJefe(jefe, filas, columnas, jugador, goblins, numGoblins, arqueros, numArqueros, cofres, numCofres, salidaX, salidaY);

        EstadoJuego est;
        est.activo = true;
        est.filas = filas;
        est.columnas = columnas;
        est.jugadorX = jugador.posX;
        est.jugadorY = jugador.posY;
        est.vida = jugador.vida;
        est.habilidad = jugador.habilidad;
        est.oro = jugador.oro;
        est.salidaX = salidaX;
        est.salidaY = salidaY;

        est.numGoblins = numGoblins;
        for(int i=0; i<numGoblins; i++) {
            est.goblins[i] = {goblins[i].getPosX(), goblins[i].getPosY(), goblins[i].getVida(), goblins[i].estaVencido(), goblins[i].estaDescubierto()};
        }

        est.numArqueros = numArqueros;
        for(int i=0; i<numArqueros; i++) {
            est.arqueros[i] = {arqueros[i].getPosX(), arqueros[i].getPosY(), arqueros[i].getVida(), arqueros[i].estaVencido(), arqueros[i].estaDescubierto()};
        }

        est.numCofres = numCofres;
        for(int i=0; i<numCofres; i++) {
            est.cofres[i] = {cofres[i].getPosX(), cofres[i].getPosY(), cofres[i].abierto, cofres[i].valor};
        }

        est.jefeX = jefe.getPosX();
        est.jefeY = jefe.getPosY();
        est.jefeVida = jefe.getVida();
        est.jefeVencido = jefe.estaVencido();
        est.jefeTurnos = jefe.getTurnos();

        guardarEstado(est);
        cout << "Juego iniciado (" << filas << "x" << columnas << "). Goblins: " << numGoblins << ", Arqueros: " << numArqueros << endl;
        mostrarTablero(filas, columnas, jugador, goblins, numGoblins, arqueros, numArqueros, cofres, numCofres, salidaX, salidaY, jefe);

        delete[] goblins;
        delete[] arqueros;
        delete[] cofres;
    }
    else if (comando == "history") {
        leerPuntajesBinarios();
    }
    else {
        EstadoJuego est;
        if (!cargarEstado(est)) {
            cout << "Error: Primero debes iniciar el juego ejecutando './juego.exe start'." << endl;
            return 0;
        }

        Personaje jugador("Heroe", est.jugadorX, est.jugadorY);
        jugador.vida = est.vida;
        jugador.habilidad = est.habilidad;
        jugador.oro = est.oro;

        Jefe jefe(est.jefeX, est.jefeY, est.jefeVida, est.jefeTurnos, est.jefeVencido);

        Goblin *goblins = new Goblin[est.numGoblins];
        for(int i=0; i<est.numGoblins; i++) {
            goblins[i] = Goblin(est.goblins[i].x, est.goblins[i].y, est.goblins[i].vida, est.goblins[i].vencido, est.goblins[i].descubierto);
        }

        Arquero *arqueros = new Arquero[est.numArqueros];
        for(int i=0; i<est.numArqueros; i++) {
            arqueros[i] = Arquero(est.arqueros[i].x, est.arqueros[i].y, est.arqueros[i].vida, est.arqueros[i].vencido, est.arqueros[i].descubierto);
        }

        Cofre *cofres = new Cofre[est.numCofres];
        for(int i=0; i<est.numCofres; i++) {
            cofres[i] = Cofre(est.cofres[i].x, est.cofres[i].y, est.cofres[i].abierto, est.cofres[i].valor);
        }

        if (comando == "board") {
            mostrarTablero(est.filas, est.columnas, jugador, goblins, est.numGoblins, arqueros, est.numArqueros, cofres, est.numCofres, est.salidaX, est.salidaY, jefe);
        }
        else if (comando == "stats") {
            jugador.imprimirStats();
        }
        else if (comando == "move") {
            if (argc >= 3) {
                string dir = argv[2];
                if (dir == "up" || dir == "down" || dir == "left" || dir == "right") {
                    jugador.mover(dir);
                    est.jugadorX = jugador.posX;
                    est.jugadorY = jugador.posY;

                    movimientojefe(jefe, jugador, est.salidaX, est.salidaY);
                    est.jefeX = jefe.getPosX();
                    est.jefeY = jefe.getPosY();
                    est.jefeTurnos = jefe.getTurnos();

                    // Daño del Jefe si alcanza al jugador
                    if (!jefe.estaVencido() && est.jugadorX == jefe.getPosX() && est.jugadorY == jefe.getPosY()) {
                        jugador.recibirDanio(40);
                        est.vida = jugador.vida;
                        cout << "¡El Jefe te ha aplastado! Pierdes 40 PV." << endl;
                    }

                    for (int i = 0; i < est.numGoblins; i++) {
                        if (!goblins[i].estaVencido() && est.jugadorX == goblins[i].getPosX() && est.jugadorY == goblins[i].getPosY()) {
                            goblins[i].descubrir();
                            jugador.recibirDanio(30);
                            est.goblins[i].descubierto = true;
                            cout << "¡Un Goblin te atacó al pisar su casilla! Pierdes 30 PV." << endl;
                        }
                    }

                    for (int i = 0; i < est.numArqueros; i++) {
                        bool rX = abs(est.jugadorX - arqueros[i].getPosX()) <= 1;
                        bool rY = abs(est.jugadorY - arqueros[i].getPosY()) <= 1;
                        if (!arqueros[i].estaVencido() && rX && rY) {
                            arqueros[i].descubrir();
                            jugador.recibirDanio(20);
                            est.arqueros[i].descubierto = true;
                            cout << "¡Un Arquero te disparó desde la distancia! Pierdes 20 PV." << endl;
                        }
                    }

                    est.vida = jugador.vida;

                    // Verificación de Fin del Juego por muerte
                    if (!jugador.estaVivo()) {
                        cout << "\n===============================" << endl;
                        cout << "         FIN DEL JUEGO         " << endl;
                        cout << "===============================" << endl;
                        cout << "Te has quedado sin vida. ¡Has muerto!" << endl;
                        int puntajeFinal = jugador.calcularPuntajeFinal(false);
                        cout << "Tu puntaje final es: " << puntajeFinal << endl;
                        guardarPuntajeBinario(jugador, puntajeFinal);
                        est.activo = false;
                    }
                    else if (jugador.posX == est.salidaX && jugador.posY == est.salidaY) {
                        cout << "¡Felicidades! Has llegado a la salida." << endl;
                        int puntajeFinal = jugador.calcularPuntajeFinal(true);
                        cout << "Tu puntaje final es: " << puntajeFinal << endl;
                        guardarPuntajeBinario(jugador, puntajeFinal);
                        est.activo = false;
                    }

                    guardarEstado(est);
                    mostrarTablero(est.filas, est.columnas, jugador, goblins, est.numGoblins, arqueros, est.numArqueros, cofres, est.numCofres, est.salidaX, est.salidaY, jefe);
                } else {
                    cout << "Dirección inválida. Usa: up, down, left, right" << endl;
                }
            } else {
                cout << "Falta especificar la dirección (ej: ./juego.exe move right)." << endl;
            }
        }
        else if (comando == "seek") {
            for (int i = 0; i < est.numCofres; i++) {
                if (jugador.posX == cofres[i].getPosX() && jugador.posY == cofres[i].getPosY()) {
                    cofres[i].explorarCofre(jugador);
                    est.cofres[i].abierto = cofres[i].abierto;
                    break;
                }
            }
            est.vida = jugador.vida;
            est.oro = jugador.oro;
            est.habilidad = jugador.habilidad;

            if (!jugador.estaVivo()) {
                cout << "\n===============================" << endl;
                cout << "         FIN DEL JUEGO         " << endl;
                cout << "===============================" << endl;
                cout << "La trampa del cofre te mató. ¡Has muerto!" << endl;
                int puntajeFinal = jugador.calcularPuntajeFinal(false);
                cout << "Tu puntaje final es: " << puntajeFinal << endl;
                guardarPuntajeBinario(jugador, puntajeFinal);
                est.activo = false;
            }

            guardarEstado(est);
        }
        else if (comando == "attack") {
            bool atacado = false;
            for (int i = 0; i < est.numGoblins; i++) {
                if (jugador.posX == goblins[i].getPosX() && jugador.posY == goblins[i].getPosY() && !goblins[i].estaVencido()) {
                    goblins[i].recibirDanio(20, jugador);
                    est.goblins[i].vida = goblins[i].getVida();
                    est.goblins[i].vencido = goblins[i].estaVencido();
                    atacado = true;
                    break;
                }
            }
            if (!atacado) {
                for (int i = 0; i < est.numArqueros; i++) {
                    bool rX = abs(jugador.posX - arqueros[i].getPosX()) <= 1;
                    bool rY = abs(jugador.posY - arqueros[i].getPosY()) <= 1;
                    if (rX && rY && !arqueros[i].estaVencido()) {
                        arqueros[i].recibirDanio(20, jugador);
                        est.arqueros[i].vida = arqueros[i].getVida();
                        est.arqueros[i].vencido = arqueros[i].estaVencido();
                        atacado = true;
                        break;
                    }
                }
            }
            if (!atacado && jugador.posX == jefe.getPosX() && jugador.posY == jefe.getPosY() && !jefe.estaVencido()) {
                jefe.recibirDanio(20, jugador);
                est.jefeVida = jefe.getVida();
                est.jefeVencido = jefe.estaVencido();
                atacado = true;
            }

            if (!atacado) {
                cout << "No hay ningún enemigo al alcance para atacar." << endl;
            }

            est.habilidad = jugador.habilidad;
            guardarEstado(est);
        }
        else {
            cout << "Comando no reconocido." << endl;
        }

        delete[] goblins;
        delete[] arqueros;
        delete[] cofres;
    }

    return 0;
}